$('#search-beer').on('submit', function(e) {
    e.preventDefault()
    var query = $(this).find('input').val()

    $.ajax({
      url: 'https://quiet-inlet-67115.herokuapp.com/api/search/all?q=' + query
    })
    .then(function(oData) {
        console.log(oData)
        $('#img-viewer').append('<div class="back-img-posted row"></div>')
        oData.forEach(function(beer) {
          // if(typeof beer.labels !== 'undefined') {
          //   console.log("beer.labels")
            $('.back-img-posted row').append(beer.name)
            // $('.back-img-posted row').html('<img class="img-resposive img-posted" src="' + beer.labels.medium + '"></div>')
          // } else {
          //   console.log("NOT beer.labels")
          //   $('.back-img-posted row').append('<div class="col-sm-3"><h3>' + beer.name + '</h3>')
          //   // $('.back-img-posted row').append('<img class="img-resposive img-posted" src="beer-icon.svg"></div>')
          // }

        })
    })
})